<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8"/>
		<title>Amaro</title>
		<base href="/"/>
		<meta name="viewport" content="width=device-width, initial-scale=1"/>
		<link rel="icon" type="image/x-icon" href="favicon.ico"/>
	<link rel="stylesheet" href="styles.css"><link rel="modulepreload" href="chunk-JC6NZA6F.js"><link rel="modulepreload" href="chunk-B35TBNCG.js"><link rel="modulepreload" href="chunk-KDH5BIP5.js"><link rel="modulepreload" href="chunk-HTEX24SK.js"><link rel="preload" href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700&display=swap" as="style"></head>
	<body>
		<app-root></app-root>
	<script src="polyfills.js" type="module"></script><script src="main.js" type="module"></script></body>
</html>
