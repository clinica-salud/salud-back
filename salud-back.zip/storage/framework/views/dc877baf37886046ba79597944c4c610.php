<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>Amaro</title>
    <base href="/" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="icon" type="image/x-icon" href="favicon.ico" />
    <link rel="stylesheet" href="styles-KH3TZ6DY.css">
    <link rel="modulepreload" href="chunk-Q5SZ6R4L.js">
    <link rel="modulepreload" href="chunk-RZICHWJM.js">
    <link rel="modulepreload" href="chunk-I5DF4SGQ.js">
    <link rel="modulepreload" href="chunk-ASUHQBTS.js">
    <link rel="modulepreload" href="chunk-AO74IJK3.js">
</head>

<body>
    <app-root></app-root>
    <script src="polyfills-RT5I6R6G.js" type="module"></script>
    <script src="main-5AORL4YJ.js" type="module"></script>
</body>

</html>
<?php /**PATH D:\Coding\Projects\Others\Amaro\salud-back\resources\views/welcome.blade.php ENDPATH**/ ?>